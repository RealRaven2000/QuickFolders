"use strict";
// this will be initialized in qf-messenger.js
// now register myself as a listener on every mail folder
var QuickFolders_mailSession = Components.classes["@mozilla.org/messenger/services/session;1"].getService(Components.interfaces.nsIMsgMailSession);

