// this is currently unused - not sure whether it will ever be necessary
console.log("QUICKFOLDERS SHUTDOWN");